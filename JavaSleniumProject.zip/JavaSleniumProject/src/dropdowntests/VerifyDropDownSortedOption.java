package dropdowntests;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class VerifyDropDownSortedOption {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 System.setProperty("webdriver.chrome.driver","D:\\ChromeDriver\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
		driver.get("https://testautomationpractice.blogspot.com/");
		WebElement element =driver.findElement(By.id("animals"));
		Select se = new Select(element);
		
		List originallist =new ArrayList();
		  List tempList =new ArrayList();
		
		List<WebElement>options=se.getOptions();
		
		for(WebElement e:options)
		{
			originallist.add(e.getText());
			tempList.add(e.getText());
		}
		
		  System.out.println("Original List:"+ originallist);
		  System.out.println("Before sorting temp list: "+tempList);
		  
		  Collections.sort(tempList);
		  
		  System.out.println("After sorting temp list: "+originallist);
		  System.out.println("After sorting temp list: "+tempList);
		  
		  if(originallist == tempList)
		  {
			  System.out.println("Drowpdown is sorted");
		  } else
		  {
			  System.out.println("Drowpdown is not sorted");
		  }
		  driver.close();
			
	}      

}
