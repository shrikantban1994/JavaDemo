package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class TestNGTestOne {
	
	WebDriver driver ;
  @Test
  public void f()  {
	  
	  System.setProperty("webdriver.chrome.driver", "C://Users//DELL//eclipse//webdriver//chromedriver_win32//chromedriver.exe");
	  WebDriver driver = new ChromeDriver();

	  String url = "https://itera-qa.azurewebsites.net/";
	  driver.get(url);
      String expectedTitle = "Home Page - Testautomation practice page";
  	  String actualTitle = driver.getTitle();
  	  Assert.assertEquals(expectedTitle, actualTitle);
  	  
  	  
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Starting the browser session");
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("Closing the browser session");
	  driver.close();
  }

}
