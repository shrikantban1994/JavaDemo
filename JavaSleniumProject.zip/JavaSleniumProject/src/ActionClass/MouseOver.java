package ActionClass;



import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseOver {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","D:\\ChromeDriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/dashboard");
	
		
		driver.manage().timeouts().implicitlyWait ( Duration.ofSeconds(5));
		
		driver.findElement(By.name("txtUsername")).sendKeys("Admin");
		driver.findElement(By.name("txtPassword")).sendKeys("admin123");
		driver.findElement(By.name("Submit")).click();
		
		Actions act = new Actions(driver);
		WebElement admin = driver.findElement(By.xpath("//*[@id=\"menu_admin_viewAdminModule\"]/b"));
		WebElement Usermng = driver.findElement(By.xpath("//*[@id=\"menu_admin_UserManagement\"]"));
		WebElement users = driver.findElement(By.xpath("//*[@id=\"menu_admin_viewSystemUsers\"]"));
		
		Thread.sleep(3000);
		act.moveToElement(admin).build().perform();
		act.moveToElement(Usermng).build().perform();
		act.moveToElement(users).click().build().perform();
		
	//	act.moveToElement(admin).moveToElement(Usermng).moveToElement(users).click().build().perform();
		
		
		driver.close();

	}

}
