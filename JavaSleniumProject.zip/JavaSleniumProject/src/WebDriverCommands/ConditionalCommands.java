package WebDriverCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ConditionalCommands {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C://Users//DELL//eclipse//webdriver//chromedriver_win32//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.facebook.com/r.php?locale=en_GB&display=page");
		System.out.println(driver.getTitle());
		
		WebElement firstname=driver.findElement(By.xpath("//input[@name='firstname']"));
		WebElement lastname=driver.findElement(By.xpath("//input[@name='lastname']"));
		
		
		if(firstname.isDisplayed() && firstname.isEnabled())
		{
			firstname.sendKeys("shrikant");
		}
		if(lastname.isDisplayed() && lastname.isEnabled())
		{
			lastname.sendKeys("ban");

	}
		// female
		System.out.println(driver.findElement(By.xpath("(//input[@name='sex'])[1]")).isSelected());
		
		// male
		System.out.println(driver.findElement(By.xpath("(//input[@name='sex'])[2]")).isSelected());
		
		if(driver.findElement(By.xpath("(//input[@name='sex'])[1]")).isSelected()==false)
		{
			driver.findElement(By.xpath("(//input[@name='sex'])[1]")).click();
		}
   }
}
