package WebDriverCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertWithTextbox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C://Users//DELL//eclipse//webdriver//chromedriver_win32//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//a[@href='#Textbox']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		
		driver.switchTo().alert().sendKeys("Automation Testing Execution");
		String ExpText = "Hello Automation Testing Execution How are you today";
		driver.switchTo().alert().accept();
		String ActText = driver.findElement(By.xpath("//*[@id=\"demo1\"]")).getText();
		
		if (ExpText.equals(ActText)==true)
		{
			System.out.println("Test case is passed");
		}else 
		{
			System.out.println("Test case is failed");
		}
				driver.close();

	}

}
