package WebDriverCommands;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwitchinWindows {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.setProperty("webdriver.chrome.driver", "C://Users//DELL//eclipse//webdriver//chromedriver_win32//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://demo.automationtesting.in/Windows.html");
		
		driver.findElement(By.xpath("//a[@href='#Tabbed']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		
		//System.out.println(driver.getTitle());
		
		Set <String> s = driver.getWindowHandles();
		
		for (String i:s)
		{
			
			String t = driver.switchTo().window(i).getTitle();
		    
			if(t.contains("Selenium"))
			{
				driver.close();
				
			}
			
		}  driver.findElement(By.xpath("//a[@href='#Seperate']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
	}

}
