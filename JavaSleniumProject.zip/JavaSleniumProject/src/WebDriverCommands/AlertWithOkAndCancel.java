package WebDriverCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

public class AlertWithOkAndCancel {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C://Users//DELL//eclipse//webdriver//chromedriver_win32//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
		driver.switchTo().alert().accept();
		
		String ActText = driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div[2]/div[2]/p")).getText();
		
		Thread.sleep(3000);
		String ExpTextOk = "You pressed Ok";
		 if(ExpTextOk.equals(ActText)==true)
		 {
			 System.out.println("Test is passed");
	     driver.switchTo().alert().dismiss();
		 String ExpTextCancel = "You Pressed Cancel";
		 
		 if(ExpTextCancel.equals(ActText)==true)
			 {
				 System.out.println("Test is passed");
			 }
			 
		 }
		 

	}

}
