package HandlingWebElement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;


public class VolenteerSignUpForm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C://Users//DELL//eclipse//webdriver//chromedriver_win32//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/");
		driver.manage().window().maximize();
		
		
//		// Dropdown list
//		driver.findElement(By.xpath("//a[text()='Dropdown']")).click();		
//		WebElement drpdown = driver.findElement(By.id("dropdown"));
//		Select t = new Select(drpdown);
//		//t.selectByIndex(1);
//		//t.selectByValue("1");
//		t.selectByVisibleText("Option 1");
//		System.out.println(t.getOptions().size());
//		
		
		// Checkbox
		driver.findElement(By.xpath("//a[text()='Checkboxes']")).click();
		System.out.println(driver.findElement(By.xpath("(//input[@type='checkbox'])[1]")).isSelected());
		driver.findElement(By.xpath("(//input[@type='checkbox'])[1]")).click();
		driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).click();
		
		
//		// Login the Application
//		driver.findElement(By.xpath("//input[@name='UserId']")).sendKeys("shrikantban99@gmail.com");
//		driver.findElement(By.xpath("//input[@name='Password']")).sendKeys("Shrikant1@");
//		driver.findElement(By.xpath("//button[@id='login']")).click();
//		
		
//		// Create New Form
//		driver.findElement(By.xpath("//button[@class='button-blue button-new']")).click();
//		driver.findElement(By.xpath("//button[@class='button-green']")).click();
//		driver.findElement(By.xpath("//input[@name='FormName2']")).sendKeys("Shrikant1");
//		driver.findElement(By.xpath("//button[@class='button-green ui-button ui-corner-all ui-widget']")).click();
//		
//		// Drop selected form 
//		WebElement From =driver.findElement(By.xpath("//td[@id='t2']"));
//		WebElement To = driver.findElement(By.xpath("//div[@class='placeholder']"));
//		Actions act = new Actions(driver);
//		act.dragAndDrop(From, To).build().perform();
		
		
		

	}

}
