package DataDrivenTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Calculation {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C://Users//DELL//eclipse//webdriver//chromedriver_win32//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		 driver.get("https://www.moneycontrol.com/fixed-income/calculator/state-bank-of-india-sbi/fixed-deposit-calculator-SBI-BSB001.html?classic=true");
		 driver.manage().window().maximize();
		 
		 //Getting Data from excel sheet
		 FileInputStream file = new FileInputStream("D:\\ChromeDriver\\chromedriver.exe");
	
		 
		 
		 //Getting the workbook instance for XLS file
		 XSSFWorkbook workbook = new XSSFWorkbook(file);
		 
		 //Get the first sheet from the workbook
		 XSSFSheet sheet = workbook.getSheet("Sheet1");
		 
		 //Get the first row of the sheet
		 int noOfRows = sheet.getLastRowNum();
		 
		 System.out.println("No of records in the excel sheet:" + noOfRows);
		 
		 for(int row = 1; row<= noOfRows; row++)
		 {
			 XSSFRow current_row = sheet.getRow(row);
			 
			XSSFCell principlecell = current_row.getCell(0);
			int princ= (int)principlecell.getNumericCellValue();
			
			XSSFCell roi = current_row.getCell(1);
			int rateofinterest =(int)roi.getNumericCellValue();
			
			XSSFCell period = current_row.getCell(2);
			int per = (int)period.getNumericCellValue();
			
			XSSFCell Frequency = current_row.getCell(3);
			String Fre = Frequency.getStringCellValue();
			
			XSSFCell MaturityValue = current_row.getCell(4);
			int Exp_mvalue =(int) MaturityValue.getNumericCellValue();
			
			driver.findElement(By.id("principal")).sendKeys(String.valueOf(princ));
			driver.findElement(By.id("interest")).sendKeys(String.valueOf(rateofinterest));
			driver.findElement(By.id("tenure")).sendKeys(String.valueOf(per));
			
			Select periodcombo = new Select ( driver.findElement(By.id("tenurePeriod")));
			periodcombo.selectByVisibleText("year(s)");
			
			Select frequency = new Select ( driver.findElement(By.id("frequency")));
			frequency.selectByVisibleText(Fre);
			
			driver.findElement(By.xpath("//*[@id=\"fdMatVal\"]/div[2]/a[1]/img")).click();
			
			String actual_mvalue = driver.findElement(By.xpath("//*[@id=\"resp_matval\"]/strong")).getText();
			
			if (Double.parseDouble(actual_mvalue)==Exp_mvalue)
			{
				System.out.println("test is passed");
				
			} else
			{
				System.out.println("test is failed");
			}
			   driver.findElement(By.xpath("//*[@id=\"fdMatVal\"]/div[2]/a[2]/img")).click();
		 }
              driver.close();
              driver.quit();
	}

}
