package Guru99;

import java.util.Set;

import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NewTest6 {
  
  public void f() {
  }
  public String baseUrl = "http://demo.guru99.com/test/newtours/";
  String driverPath = "C://Users//DELL//eclipse//webdriver//chromedriver_win32//chromedriver.exe";
  public WebDriver driver; 
  public String expected = null;
  public String actual = null;
  
  @BeforeTest
  public void launchBrowser() {
      System.out.println("launching chrome browser"); 
      System.setProperty("webdriver.chrome.driver", driverPath);
      driver= new ChromeDriver();
      driver.get(baseUrl);
  }
  @BeforeMethod
  public void verifyHomepageTitle() {
      String expectedTitle = "Welcome: Mercury Tours";
      String actualTitle = driver.getTitle();
      Assert.assertEquals(actualTitle, expectedTitle);
  }
      @Test(priority = 0)
  public void register(){
      driver.findElement(By.linkText("REGISTER")).click() ;
      expected = "Register: Mercury Tours";
      actual = driver.getTitle();
      Assert.assertEquals(actual, expected);
  }
      @Test(priority = 1)
  public void support() {
        driver.findElement(By.linkText("SUPPORT")).click() ;
        expected = "Under Construction: Mercury Tours";
        actual = driver.getTitle();
        Assert.assertEquals(actual, expected);
  }
  @AfterMethod
  public void goBackToHomepage ( ) throws InterruptedException {
	  driver.findElement(By.linkText("Home")).click();
	  String ParentId = driver.getWindowHandle();
	  Set<String> handles = driver.getWindowHandles();
	  for(String handle : handles) {
		  if (!handle.equals(ParentId))
		  {
			  driver.switchTo().window(handle);
			  driver.close();
		  }
	  }
               driver.switchTo().window(ParentId);
        
  }
   
  @AfterTest
  public void terminateBrowser(){
      driver.close();
  }
      
      
}
