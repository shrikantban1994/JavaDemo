package Guru99;

import org.junit.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;

public class NewTest2 {
  
  public void f() {
	  
  }
	  
	  @Test 
      public void c_test() {
		  Assert.fail();
  }
	  @Test 
	  public void a_test() {
		  Assert.assertTrue(true);
	  }
	  @Test 
	  public void b_test() {
		  throw new SkipException("Skipping b_test...");
	  }
}
